module tournamentmanagerproject {
    requires javafx.controls;
    requires javafx.fxml;

    opens tournamentmanagerproject to javafx.fxml;
    exports tournamentmanagerproject;
}
