package tournamentmanagerproject;

/**
 *
 * @author Evelyn Pyradkin
 * @date 1/25/2025
 * @description Represents player in tournament system.
 * 
 */
public class Player 
{
    private String name;
    private boolean isInMatch;
    private int gamesPlayed;
    private int gamesWon;

    /**
     * 
     * Constructs a new Player with given name, initializes all fields
     * @param - name: the player's name
     * 
     */
    public Player(String name) {
        this.name = name;
        this.isInMatch = false;
        this.gamesPlayed = 0;
        this.gamesWon = 0;
    }

    /**
     * 
     * Get method - retrieves player's name
     * @return name: the player's name
     * 
     */
    public String getName() {
        return name;
    }

    /**
     * 
     * Checks if player is in match currently, true/false
     * @return True if in match, false otherwise
     * 
     */
    public boolean isInMatch() {
        return isInMatch;
    }

    /**
     * 
     * Set method - sets whether the player is in a match
     * @param inMatch: true if player is in match, false otherwise
     * 
     */
    public void setInMatch(boolean inMatch) {
        this.isInMatch = inMatch;
    }

    /**
     * 
     * Get method - gets the number of games played by the player
     * @return the number of games played
     * 
     */
    public int getGamesPlayed() {
        return gamesPlayed;
    }

    /**
     * 
     * Increments the number of games played by player
     * 
     */
    public void incrementGamesPlayed() {
        this.gamesPlayed++;
    }

    /**
     * 
     * Get method - gets the number of games won by the player
     * 
     * @return the number of games won
     * 
     */
    public int getGamesWon() {
        return gamesWon;
    }

    /**
     * 
     * Increments the number of games won by the player
     * 
     */
    public void incrementGamesWon() {
        this.gamesWon++;
    }
}
