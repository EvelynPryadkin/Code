package tournamentmanagerproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import tournamentmanagerproject.Match.Status;

/**
 *
 * @author savan
 */
public class TournamentLogic 
{
    private ObservableList<Player> players = FXCollections.observableArrayList();
    private ObservableList<Match> matches = FXCollections.observableArrayList();

    public void registerPlayer(String name) 
    {
        Player newPlayer = new Player(name);
        players.add(newPlayer);
        generateInitialMatches();

        // Generate matches with all existing players
    }  
    
    private void generateInitialMatches() 
    {
        for (Player player : players) 
        {
            for (Player otherPlayer : players) 
            {
                if (!player.equals(otherPlayer)) 
                {
                    matches.add(new Match(player, otherPlayer));
                }
            }
        }
    }
    
    public ObservableList<Match> getActiveMatches() 
    {
        return matches.filtered(match -> match.getStatus() == Match.Status.ACTIVE);
    }
    
    public void generateMatches() 
    {
        for (Match match : matches) 
        {
            if (match.getStatus() == Match.Status.CREATED &&
                !match.getPlayer1().isInMatch() &&
                !match.getPlayer2().isInMatch()) 
            {

                match.setStatus(Match.Status.ACTIVE);
                match.getPlayer1().setInMatch(true);
                match.getPlayer2().setInMatch(true);
            }
        }
    }
    
     public void recordMatchWinner(Match match, Player winner) 
     {
        match.setStatus(Match.Status.COMPLETED);
        match.getPlayer1().setInMatch(false);
        match.getPlayer2().setInMatch(false);

        winner.incrementGamesWon();
        match.getPlayer1().incrementGamesPlayed();
        match.getPlayer2().incrementGamesPlayed();

        // Sort players by number of games won
        FXCollections.sort(players, (p1, p2) -> Integer.compare(p2.getGamesWon(), p1.getGamesWon()));
    }

    public ObservableList<Player> getLeaderboard() 
    {
        return players;
    }
    
    public void recordMatchWinner(Player winner)
    {
        boolean matchFound = false;
        Match activeMatch = null;
        
        for (Match match : getActiveMatches())
        {
            if ((match.getPlayer1() == winner || match.getPlayer2() == winner)
                    && (match.getPlayer1().isInMatch() || match.getPlayer2().isInMatch()))
            {
                activeMatch = match;
                matchFound = true;
                break;
            }
        }
        
        activeMatch.setStatus(Status.COMPLETED);
        activeMatch.getPlayer1().setInMatch(false);
        activeMatch.getPlayer2().setInMatch(false);
        winner.incrementGamesWon();
        activeMatch.getPlayer1().incrementGamesPlayed();
        activeMatch.getPlayer2().incrementGamesPlayed();
    }
    
}
