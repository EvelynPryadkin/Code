package tournamentmanagerproject;

/**
 *
 * @author Savannah Larsen
 * @date 1/25/2025
 * @description 
 * 
 */

public class Match 
{
    
    private Player player1;
    private Player player2;
    private Status status;
    
    private int player1GamesPlayed = 0;
    private int player1GamesWon = 0;
    
    private int player2GamesPlayed = 0;
    private int player2GamesWon = 0;
    /**
     * 
     * Constructs a new Match with given players, initializes all fields
     * @param - player1: first player
     * @param - player2: second player
     * 
     */
    public Match(Player p1, Player p2)
    {
        this.player1 = p1;
        this.player2 = p2;
        this.status = Status.CREATED;
        
        // initialize others here
        
        
    }
    
    public void updateStatus(Status newStatus)
    {
        this.status = newStatus;
        
        // using a switch statement here might be where I go wrong
        switch (newStatus)
        {
            case ACTIVE:
                //player1.setActiveMatch(true);
        }
    }
    
    
    // get and set methods below
    /**
     * 
     * Gets first player of the match
     * @return the first player
     * 
     */
    public Player getPlayer1()
    {
        return player1;
    }
    
    /**
     * 
     * Sets first player of the match
     * @return the new first player
     * 
     */
    public void setPlayer1(Player player1)
    {
        this.player1 = player1;
    }
    
    /**
     * 
     * Gets second player of the match
     * @return the second player
     * 
     */
    public Player getPlayer2()
    {
        return player2;
    }
    
    /**
     * 
     * Sets second player of the match
     * @return the new second player
     * 
     */
    public void setPlayer2(Player player2)
    {
        this.player2 = player2;
    }
    
    /**
     * 
     * Sets the status of the match
     * @return the match status
     * 
     */
    public Status getStatus()
    {
        return status;
    }
    
    /**
     * 
     * Sets the status of the match
     * @param the match status
     * 
     */
    public void setStatus(Status status)
    {
        this.status = status;
    }
    
    /**
     * Gets the number of games played by player 1
     * 
     * @return the number of games played by player 1
     * 
     */
    public int getPlayer1GamesPlayed()
    {
        return player1GamesPlayed;
    }
    
    /**
     * 
     * Sets the number of games played by player 1
     * 
     * @param player1GamesPlayed - the number of new games played by player
     * 
     */
    public void setPlayer1GamesPlayed (int player1GamesPlayed)
    {
        this.player1GamesPlayed = player1GamesPlayed;
    }
    
    /**
     * Gets the number of games won by player 1
     * 
     * @return the number of games won by player 1
     * 
     */
    public int getPlayer1GamesWon()
    {
       return player1GamesWon;
    }
    
    /**
     * Sets the number of games won by player 1
     * 
     * @param player1GamesWon the new number of games won by player 2
     * 
     */
    public void setPlayer1GamesWon(int player1GamesWon)
    {
        this.player1GamesWon = player1GamesWon;
    }
    
    /**
     * Gets the number of games played by player 2
     * 
     * @return the number of games played by player 2
     * 
     */
    public int getPlayer2GamesPlayed()
    {
        return player2GamesPlayed;
    }
    
    /**
     * 
     * Sets the number of games played by player 2
     * 
     * @param player2GamesPlayed - the number of new games played by player
     * 
     */
    public void setPlayer2GamesPlayed (int player2GamesPlayed)
    {
        this.player2GamesPlayed = player2GamesPlayed;
    }
    
    /**
     * Gets the number of games won by player 2
     * 
     * @return the number of games won by player 2
     * 
     */
    public int getPlayer2GamesWon()
    {
       return player2GamesWon;
    }
    
    /**
     * Sets the number of games won by player 2
     * 
     * @param player2GamesWon the new number of games won by player 2
     * 
     */
    public void setPlayer2GamesWon(int player2GamesWon)
    {
        this.player2GamesWon = player2GamesWon;
    }
    
    // Enum for match status
    public enum Status // enums hold a very specific set of fixed constants
    {
        CREATED,
        ACTIVE,
        COMPLETED
    }
}
