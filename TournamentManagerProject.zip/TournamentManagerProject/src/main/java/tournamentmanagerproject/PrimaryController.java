package tournamentmanagerproject;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ComboBox;



public class PrimaryController 
{
   private TournamentLogic tournamentLogic;
    
// member veriables to get access to the UI
    @FXML TextField playerNameText;
    @FXML TextField winnerText;
    @FXML Label confirmationText;
    @FXML Button generateMatchesButton;
    @FXML ListView<Match> activeMatchesList;
    @FXML ListView<Player> leaderboardList;
    @FXML ComboBox<Player> playerSelector;
    

    @FXML
    void getRegistration(ActionEvent event)
    {
        String registrationName = playerNameText.getText();
        String confirmation = "Congratulations " + registrationName + " is registered!";
        confirmationText.setText(confirmation);
        tournamentLogic.registerPlayer(registrationName);
    }
    
    @FXML
    private void generateMatches(ActionEvent event) {
        tournamentLogic.generateMatches();
        updateUI();
    }
    
    
    @FXML
    private void selectMatch(Match match)
    {
        playerSelector.setItems(FXCollections.observableArrayList(match.getPlayer1(), match.getPlayer2()));
        playerSelector.getSelectionModel().selectFirst();
    }
    
    @FXML
    private void submitWinner()
    {
        Player selectedPlayer = playerSelector.getValue();
        if (selectedPlayer != null)
        {
            tournamentLogic.recordMatchWinner(selectedPlayer);
            updateUI();
        }
        else
        {
            System.out.print("Error.");
        }
    }
    
    private void updateUI() 
    {
        activeMatchesList.getItems().setAll(tournamentLogic.getActiveMatches());
        leaderboardList.getItems().setAll(tournamentLogic.getLeaderboard());
    }

    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
